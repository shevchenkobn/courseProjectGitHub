/*!***************************************************
 * mark.js
 * https://github.com/julmot/mark.js
 * Copyright (c) 2014–2017, Julian Motz
 * Released under the MIT license https://git.io/vwTVl
 *****************************************************/
"use strict";
// Configuration for Jasmine or other components related to the specs
jasmine.getFixtures().fixturesPath = "base/test/fixtures";
jasmine.DEFAULT_TIMEOUT_INTERVAL = 60000;
